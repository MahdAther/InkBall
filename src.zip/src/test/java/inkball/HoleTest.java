package inkball;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.Test;

import processing.core.PApplet;
import processing.core.PImage;

public class HoleTest {

    private PApplet app;
    private PImage testSprite;
    private Hole hole;

    public void setUp() {
        app = new PApplet();
        testSprite = new PImage(100, 100); // Create a sample sprite with width and height 100
        hole = new Hole(testSprite, 30, 40, "Hole/path");
    }

    @Test
    public void testInitialX() {
        // Test if the initial x-coordinate is set correctly
        assertEquals(30, hole.getX(), "The initial x-coordinate should be 30");
    }

    @Test
    public void testInitialY() {
        // Test if the initial y-coordinate is set correctly
        assertEquals(40, hole.getY(), "The initial y-coordinate should be 40");
    }

    @Test
    public void testSetAndGetX() {
        // Test if the x-coordinate can be updated and retrieved correctly
        hole.setX(75);
        assertEquals(75, hole.getX(), "The x-coordinate should be updated to 75");
    }

    @Test
    public void testSetAndGetY() {
        // Test if the y-coordinate can be updated and retrieved correctly
        hole.setY(85);
        assertEquals(85, hole.getY(), "The y-coordinate should be updated to 85");
    }

    @Test
    public void testInitialWidth() {
        // Test if the initial width of the sprite is set correctly
        assertEquals(100, hole.getWidth(), "The initial width should be 100");
    }

    @Test
    public void testSetAndGetWidth() {
        // Test if the width can be updated and retrieved correctly
        hole.setWidth(150);
        assertEquals(150, hole.getWidth(), "The width should be updated to 150");
    }

    @Test
    public void testInitialHeight() {
        // Test if the initial height of the sprite is set correctly
        assertEquals(100, hole.getHeight(), "The initial height should be 100");
    }

    @Test
    public void testSetAndGetHeight() {
        // Test if the height can be updated and retrieved correctly
        hole.setHeight(200);
        assertEquals(200, hole.getHeight(), "The height should be updated to 200");
    }

    @Test
    public void testGetSprite() {
        // Test if the sprite is correctly returned
        assertEquals(testSprite, hole.getSprite(), "The sprite should be the same as the test sprite");
    }

    @Test
    public void testGetSpritePath() {
        // Test if the sprite path is correctly returned
        assertEquals("Hole/path", hole.getSpritePath(), "The sprite path should be 'tile/path'");
    }

    @Test
    public void testDraw() {
        // Test if the draw method executes without any exceptions
        try {
            hole.draw(app);
        } catch (Exception e) {
            fail("The draw method should not throw an exception");
        }
    }
}
