package inkball;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.Test;

import processing.core.PApplet;
import processing.core.PImage;

public class TileTest {

    private PApplet app;
    private PImage testSprite;
    private Tile tile;

    public void setUp() {
        app = new PApplet();
        testSprite = new PImage(100, 100); // Create a sample sprite with width and height 100
        tile = new Tile(testSprite, 30, 40, "tile/path");
    }

    @Test
    public void testInitialX() {
        // Test if the initial x-coordinate is set correctly
        assertEquals(30, tile.getX(), "The initial x-coordinate should be 30");
    }

    @Test
    public void testInitialY() {
        // Test if the initial y-coordinate is set correctly
        assertEquals(40, tile.getY(), "The initial y-coordinate should be 40");
    }

    @Test
    public void testSetAndGetX() {
        // Test if the x-coordinate can be updated and retrieved correctly
        tile.setX(75);
        assertEquals(75, tile.getX(), "The x-coordinate should be updated to 75");
    }

    @Test
    public void testSetAndGetY() {
        // Test if the y-coordinate can be updated and retrieved correctly
        tile.setY(85);
        assertEquals(85, tile.getY(), "The y-coordinate should be updated to 85");
    }

    @Test
    public void testInitialWidth() {
        // Test if the initial width of the sprite is set correctly
        assertEquals(100, tile.getWidth(), "The initial width should be 100");
    }

    @Test
    public void testSetAndGetWidth() {
        // Test if the width can be updated and retrieved correctly
        tile.setWidth(150);
        assertEquals(150, tile.getWidth(), "The width should be updated to 150");
    }

    @Test
    public void testInitialHeight() {
        // Test if the initial height of the sprite is set correctly
        assertEquals(100, tile.getHeight(), "The initial height should be 100");
    }

    @Test
    public void testSetAndGetHeight() {
        // Test if the height can be updated and retrieved correctly
        tile.setHeight(200);
        assertEquals(200, tile.getHeight(), "The height should be updated to 200");
    }

    @Test
    public void testGetSprite() {
        // Test if the sprite is correctly returned
        assertEquals(testSprite, tile.getSprite(), "The sprite should be the same as the test sprite");
    }

    @Test
    public void testGetSpritePath() {
        // Test if the sprite path is correctly returned
        assertEquals("tile/path", tile.getSpritePath(), "The sprite path should be 'tile/path'");
    }

    @Test
    public void testDraw() {
        // Test if the draw method executes without any exceptions
        try {
            tile.draw(app);
        } catch (Exception e) {
            fail("The draw method should not throw an exception");
        }
    }
}
