package inkball;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

import processing.core.PApplet;
import processing.core.PImage;

public class GameObjectTest {
    
    // Concrete implementation of GameObject for testing
    private class TestGameObject extends GameObject {
        public TestGameObject(PImage sprite, float x, float y, String spritePath) {
            super(sprite, x, y, spritePath);
        }
    }
    
    private PImage mockSprite;
    private TestGameObject gameObject;
    private static final String TEST_SPRITE_PATH = "test/sprite.png";
    private static final float INITIAL_X = 100;
    private static final float INITIAL_Y = 200;
    
    public void setup() {
        // Create a mock PImage for testing
        mockSprite = new PImage(50, 50);
        gameObject = new TestGameObject(mockSprite, INITIAL_X, INITIAL_Y, TEST_SPRITE_PATH);
    }
    
    /**
     * Test the constructor and initial values
     */
    @Test
    public void testConstructor() {
        assertEquals(INITIAL_X, gameObject.getX(), "Initial X coordinate should match constructor value");
        assertEquals(INITIAL_Y, gameObject.getY(), "Initial Y coordinate should match constructor value");
        assertEquals(TEST_SPRITE_PATH, gameObject.getSpritePath(), "Sprite path should match constructor value");
        assertNotNull(gameObject.getSprite(), "Sprite should not be null");
    }
    
    /**
     * Test setting and getting X coordinate
     */
    @Test
    public void testXCoordinate() {
        int newX = 150;
        gameObject.setX(newX);
        assertEquals(newX, gameObject.getX(), "X coordinate should be updated after setX()");
    }
    
    /**
     * Test setting and getting Y coordinate
     */
    @Test
    public void testYCoordinate() {
        int newY = 250;
        gameObject.setY(newY);
        assertEquals(newY, gameObject.getY(), "Y coordinate should be updated after setY()");
    }
    
    /**
     * Test setting and getting width
     */
    @Test
    public void testWidth() {
        int newWidth = 100;
        gameObject.setWidth(newWidth);
        assertEquals(newWidth, gameObject.getWidth(), "Width should be updated after setWidth()");
    }
    
    /**
     * Test setting and getting height
     */
    @Test
    public void testHeight() {
        int newHeight = 75;
        gameObject.setHeight(newHeight);
        assertEquals(newHeight, gameObject.getHeight(), "Height should be updated after setHeight()");
    }
    
    /**
     * Test sprite path setter and getter
     */
    @Test
    public void testSpritePath() {
        String newPath = "new/path/sprite.png";
        gameObject.setSpritePath(newPath);
        assertEquals(newPath, gameObject.getSpritePath(), "Sprite path should be updated after setSpritePath()");
    }
    
    /**
     * Test sprite getter
     */
    @Test
    public void testGetSprite() {
        assertEquals(mockSprite, gameObject.getSprite(), "getSprite() should return the sprite set in constructor");
    }
    
    /**
     * Test draw method (Basic verification that it doesn't throw exceptions)
     */
    @Test
    public void testDraw() {
        PApplet mockApp = new PApplet();
        // This mainly tests that draw() doesn't throw exceptions
        assertDoesNotThrow(() -> gameObject.draw(mockApp), "draw() should not throw exceptions");
    }
}