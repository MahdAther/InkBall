package inkball;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LevelConfigTest {
    private LevelConfig levelConfig;
    private static final String CONFIG_PATH = "src/test/resources/config.json";
    
    @BeforeEach
    public void setup() {
        levelConfig = new LevelConfig(CONFIG_PATH);
    }

    /**
     * Test that levels are loaded correctly from the config file
     */
    @Test
    public void testLevelsLoading() {
        List<LevelConfig.Level> levels = levelConfig.getLevels();
        assertEquals(3, levels.size(), "Should load 3 levels from config");
        
        // Test first level properties
        LevelConfig.Level level1 = levels.get(0);
        assertEquals("level1.txt", level1.getLayout());
        assertEquals(120, level1.getTime());
        assertEquals(10, level1.getSpawnInterval());
        assertEquals(1.0, level1.getScoreIncreaseModifier());
        assertEquals(1.0, level1.getScoreDecreaseModifier());
        
        // Test second level properties
        LevelConfig.Level level2 = levels.get(1);
        assertEquals("level2.txt", level2.getLayout());
        assertEquals(180, level2.getTime());
        assertEquals(6, level2.getSpawnInterval());
        assertEquals(1.2, level2.getScoreIncreaseModifier());
        assertEquals(1.1, level2.getScoreDecreaseModifier());
    }

    /**
     * Test ball paths are loaded correctly for each level
     */
    @Test
    public void testBallsLoading() {
        List<LevelConfig.Level> levels = levelConfig.getLevels();
        
        // Test first level balls
        ArrayList<String> level1Balls = levels.get(0).getBalls();
        assertEquals(6, level1Balls.size(), "Level 1 should have 6 balls");
        assertEquals("src/main/resources/inkball/ball2.png", level1Balls.get(0), "First ball should be blue");
        assertEquals("src/main/resources/inkball/ball1.png", level1Balls.get(1), "Second ball should be orange");
        
        // Test third level balls (all grey)
        ArrayList<String> level3Balls = levels.get(2).getBalls();
        assertEquals(8, level3Balls.size(), "Level 3 should have 8 balls");
        for (String ballPath : level3Balls) {
            assertEquals("src/main/resources/inkball/ball0.png", ballPath, "All balls in level 3 should be grey");
        }
    }

    /**
     * Test path to color name conversion
     */
    @Test
    public void testPathToName() {
        assertEquals("grey", levelConfig.pathToName("src/main/resources/inkball/ball0.png"));
        assertEquals("orange", levelConfig.pathToName("src/main/resources/inkball/ball1.png"));
        assertEquals("blue", levelConfig.pathToName("src/main/resources/inkball/ball2.png"));
        assertEquals("green", levelConfig.pathToName("src/main/resources/inkball/ball3.png"));
        assertEquals("yellow", levelConfig.pathToName("src/main/resources/inkball/ball4.png"));
        assertEquals("unknown", levelConfig.pathToName("invalid/path.png"));
    }

    /**
     * Test score increase values for correct hole captures
     */
    @Test
    public void testScoreIncreaseFromHoleCapture() {
        assertEquals(70, levelConfig.getScoreIncreaseFromHoleCapture("grey"));
        assertEquals(50, levelConfig.getScoreIncreaseFromHoleCapture("orange"));
        assertEquals(50, levelConfig.getScoreIncreaseFromHoleCapture("blue"));
        assertEquals(50, levelConfig.getScoreIncreaseFromHoleCapture("green"));
        assertEquals(100, levelConfig.getScoreIncreaseFromHoleCapture("yellow"));
        assertEquals(0, levelConfig.getScoreIncreaseFromHoleCapture("invalid"));
    }

    /**
     * Test score decrease values for wrong hole captures
     */
    @Test
    public void testScoreDecreaseFromWrongHole() {
        assertEquals(0, levelConfig.getScoreDecreaseFromWrongHole("grey"));
        assertEquals(25, levelConfig.getScoreDecreaseFromWrongHole("orange"));
        assertEquals(25, levelConfig.getScoreDecreaseFromWrongHole("blue"));
        assertEquals(25, levelConfig.getScoreDecreaseFromWrongHole("green"));
        assertEquals(100, levelConfig.getScoreDecreaseFromWrongHole("yellow"));
        assertEquals(0, levelConfig.getScoreDecreaseFromWrongHole("invalid"));
    }

    /**
     * Test case sensitivity in color names
     */
    @Test
    public void testColorCaseSensitivity() {
        assertEquals(70, levelConfig.getScoreIncreaseFromHoleCapture("GREY"));
        assertEquals(50, levelConfig.getScoreIncreaseFromHoleCapture("Blue"));
        assertEquals(25, levelConfig.getScoreDecreaseFromWrongHole("GREEN"));
        assertEquals(100, levelConfig.getScoreDecreaseFromWrongHole("YeLLoW"));
    }

    /**
     * Test loading with invalid file path
     */
    @Test
    public void testInvalidConfigPath() {
        LevelConfig invalidConfig = new LevelConfig("invalid/path.json");
        assertTrue(invalidConfig.getLevels().isEmpty(), "Levels list should be empty with invalid config path");
    }
}