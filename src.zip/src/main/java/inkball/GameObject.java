package inkball; 

import processing.core.PApplet; 
import processing.core.PImage;

public abstract class GameObject { 
     /** x-coordinate */
    protected float x; 

     /** y-coordinate */
    protected float y; 

     /** Image of Sprite */
    protected PImage sprite; 

     /** Path for sprite */
    protected String spritePath;

    /**
     * {@code GameObject} Constructs a GameObject with the specified image, position, and sprite path.
     *
     * @param sprite     the {@code PImage} representing the visual appearance of an object
     * @param x          the x-coordinate of the object's position
     * @param y          the y-coordinate of the object's position
     * @param spritePath the file path to the sprite image used for the object
     */
    public GameObject(PImage sprite, float x, float y, String spritePath) {
        this.x = x; // x-coord
        this.y = y; // y-coord
        this.sprite = sprite; // sprite

        this.spritePath = spritePath; // spritepath
    }

    /** 
     * Sets the x-coordinate for the GameObject.
     * 
     * @param x the x-coordinate of the object's position
     */
    public void setX(int x){ // setter for x-coord 
        this.x = x; 
    }

    /** 
     * Gets the x-coordinate for the GameObject.
     * 
     * @return x-cooridnate
     */
    public float getX(){ // getter for x-coord 
        return x; 
    }

    /** 
     * Sets the y-coordinate for the GameObject.
     * 
     * @param y the y-coordinate of the object's position
     */
    public void setY(int y){  // setter for y-coord 
        this.y = y; 
    }

    /** 
     * Gets the y-coordinate for the GameObject.
     * 
     * @return y-cooridnate
     */
    public float getY(){ // getter for y-coord
        return y;  
    }

    /**
     * Sets the width of the object, by resizing the whole sprite
     * with the width
     * 
     * @param newWidth the new width of the object
     */
    public void setWidth(int newWidth) {  // setter for object width
        this.sprite.resize(newWidth, this.sprite.height);
    }

    /** 
     * Gets the object width
     * 
     * @return object width
     */
    public float getWidth(){ // getter for object width
        return this.sprite.width; 
    }

    /**
     * Sets the height of the object, by resizing the whole object
     * with the height
     * 
     * @param newHeight the new height of the object
     */
    public void setHeight(int newHeight) { // setter for object height
        this.sprite.resize(this.sprite.width, newHeight);
    }

    /** 
     * Gets the object height
     * 
     * @return object height
     */
    public float getHeight(){ // getter for height
        return this.sprite.height;
    }

    /**
     * Gets the image of the object
     * 
     * @return  Objects's image
     */
    public PImage getSprite() { // getter for sprite height
        return this.sprite;
    }

    /**
     * Sets the path of a sprite of object
     * 
     * @param path the new path of the path
     */
    public void setSpritePath(String path) {  // setter for sprite path
        this.spritePath = path;
    }

    /** 
     * Gets the path of a sprite of object
     * 
     * @return the path of the object's sprite
     */
    public String getSpritePath() { // getter for sprite path
        return this.spritePath;
    }

    /**
     * Draws the sprite/object in app
     * 
     * @param app The app in which the object is drawn in
     */
    public void draw(PApplet app){  // draw sprite 
        app.image(this.sprite, this.x, this.y); 
    }
}