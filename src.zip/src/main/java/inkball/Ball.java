package inkball;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

/**
 * The {@code Ball} class represents a ball in the Inkball game. It extends the {@code GameObject}
 * class and includes properties such as speed, movement state, collision objects (walls and holes),
 * and attraction behavior.
 */
public class Ball extends GameObject {
    /** Speed in the x-direction. */
    private float xspeed;
    
    /** Speed in the y-direction. */
    private float yspeed;

    /** Indicates whether the ball is currently moving. */
    private boolean moving;
    
    /** A list of {@code Wall} objects representing the walls the ball may collide with. */
    private ArrayList<Wall> walls;
    
    /** The original width of the ball's sprite. */
    private float originalWidth;
    
    /** The original height of the ball's sprite. */
    private float originalHeight;
    
    /** A list of {@code Hole} objects representing the holes in the game. */
    private ArrayList<Hole> holes;

    /** The radius(32 px) within which the ball is attracted to a hole. */
    private static final float ATTRACTION_RADIUS = 32.0f;
    
    /** The force of attraction(10%) applied when the ball is near a hole. */
    private static final float ATTRACTION_FORCE = 0.01f;
    
    /** The static final distance threshold(12px) for the ball to be considered captured by a hole. */
    private static final float CAPTURE_THRESHOLD = 12.0f;

    /** Reference to the {@code PApplet} application for drawing and other Processing functionalities. */
    private PApplet app;

    /** Indicates whether the ball has been captured by a hole. Intially false. */
    private boolean captured = false;
    
    /** Indicates whether the ball is currently being captured by a hole. Intially false */
    private boolean isBeingCaptured = false;
    
    /** The {@code Hole} that is capturing the ball, if any. */
    private Hole captureHole;

    /** The original sprite image for the ball. */
    private PImage originalSprite;
    
    /** The current scale factor of the ball's sprite, used for size adjustments. */
    private float currentScale = 1.0f;

    /**
     * Constructs a new {@code Ball} object and specifies the behaviour of the ball. 
     * Where the ball's physics with walls and holes is defined here. 
     * 
     *
     * @param sprite     The sprite image for the ball.
     * @param x          The initial x-coordinate of the ball.
     * @param y          The initial y-coordinate of the ball.
     * @param spritePath The path to the sprite image file.
     * @param walls      The list of walls that the ball may collide with.
     * @param holes      The list of holes in the game.
     * @param app        The PApplet application reference for drawing and processing.
     */
    public Ball(PImage sprite, float x, float y, String spritePath, ArrayList<Wall> walls, ArrayList<Hole> holes, PApplet app) {
        super(sprite, x, y, spritePath); // Construct sprite, x, y and spritepath from superclass of GameObject

        BallVelocity generator = new BallVelocity();
        BallVelocity.Pair values = generator.assignRandomValues();

        this.xspeed = values.x;
        this.yspeed = values.y;

        this.moving = true;

        this.walls = walls;
        this.holes = holes;

        this.originalWidth = sprite.width;
        this.originalHeight = sprite.height;
        this.app = app;

        this.originalSprite = sprite;

    }

    /**
     * Draws the ball's sprite at its current position. 
     * Where scaled ball is shown if near a spawner. 
     *
     * @param app The PApplet application for rendering.
     */
    @Override
    public void draw(PApplet app) {
        if (!captured) {  // Only draw if not captured
            if (!isBeingCaptured) { // When not being captured draw the unscaled sprite
                app.image(this.originalSprite, this.x, this.y);
            } else {
                // Draw with scaled dimensions based on distance to hole
                float scaleX = this.sprite.width / originalWidth;
                float scaleY = this.sprite.height / originalHeight;
                app.image(this.sprite, 
                         this.x + (originalWidth * (1 - scaleX) / 2), 
                         this.y + (originalHeight * (1 - scaleY) / 2), 
                         this.sprite.width, 
                         this.sprite.height);
            }
        }
    }

    /**
     * Updates the ball's position, handles attraction to holes, and checks for collisions.
     *
     * @param lines The list of line segments used for line collision detection.
     */
    public void tick(ArrayList<ArrayList<float[]>> lines) {
        if (this.moving && !captured) {  // Add captured check
            // Check for hole attraction before moving
            Hole attractingHole = checkHoleAttraction();
            
            if (attractingHole != null) {
                // Apply hole attraction force
                applyHoleAttraction(attractingHole);
                
                // Check if ball should be captured
                if (shouldCaptureBall(attractingHole)) {
                    captureByHole(attractingHole);
                    return;
                }
            }

            // Update position of ball
            this.x += this.xspeed;
            this.y += this.yspeed;
            
            // Handle other collisions
            handleCollisions(lines);
        }
    }

     /**
     * Captures the ball within the specified hole, stopping its movement.
     *
     * @param hole The {@code Hole} capturing the ball.
     */
    private void captureByHole(Hole hole) {
        // Stop the ball
        this.moving = false;
        this.xspeed = 0;
        this.yspeed = 0;
        
        // Mark as captured 
        this.captured = true;
        this.captureHole = hole;
        
        //Set final position to hole center
        this.x = hole.getX() + 32 - (this.sprite.width / 2);
        this.y = hole.getY() + 32 - (this.sprite.height / 2);
    }

    /**
     * Retrieves the hole that captured the ball, if any.
     *
     * @return The hole that captured the ball, or {@code null} if none.
     */
    public Hole capturedHole(){ 
        return this.captureHole;
    }

    /**
     * Checks if the ball has been captured by a hole.
     *
     * @return {@code true} if the ball has been captured; otherwise, {@code false}.
     */
    public boolean isCaptured() {
        return captured;
    }

    /**
     * Checks if the ball is within the attraction range of any hole.
     *
     * @return The nearest hole within attraction range, or {@code null} if none.
     */
    private Hole checkHoleAttraction() {
        for (Hole hole : holes) {
            // Calculate center points of hole and ball
            float holeCenterX = hole.getX() + 32; // Center of 2x2 tile space
            float holeCenterY = hole.getY() + 32;
            float ballCenterX = this.x + this.sprite.width / 2;
            float ballCenterY = this.y + this.sprite.height / 2;
            
            // Calculate distance to hole center
            float distance = PApplet.dist(ballCenterX, ballCenterY, holeCenterX, holeCenterY);
            
            // If distance from ball to hole is < attraction radius then hole is returned 
            if (distance < ATTRACTION_RADIUS) {
                return hole;
            }
        }
        return null;
    }

    /**
     * Applies attraction force towards the specified hole if within range.
     *
     * @param hole The hole attracting the ball.
     */
    private void applyHoleAttraction(Hole hole) {
        // Calculate centers of hole and ball
        float holeCenterX = hole.getX() + 32;
        float holeCenterY = hole.getY() + 32;
        float ballCenterX = this.x + this.sprite.width / 2;
        float ballCenterY = this.y + this.sprite.height / 2;
        
        // Calculate vector from ball to hole
        float dx = holeCenterX - ballCenterX;
        float dy = holeCenterY - ballCenterY;
        
        // Calculate distance
        float distance = PApplet.dist(ballCenterX, ballCenterY, holeCenterX, holeCenterY);
        
        // Mark ball as being captured when in attraction range
        if (distance < ATTRACTION_RADIUS) {
            isBeingCaptured = true;
            
            // Calculate attraction force
            float attractionForce = ATTRACTION_FORCE * (ATTRACTION_RADIUS - distance) / ATTRACTION_RADIUS;
            
            // Add attraction velocity
            this.xspeed += dx * attractionForce;
            this.yspeed += dy * attractionForce;
            
            // Scale ball size based on distance, but never smaller than 20% of original size
            float scale = PApplet.map(distance, 0, ATTRACTION_RADIUS, 0.2f, 1.0f);
            scale = PApplet.constrain(scale, 0.2f, 1.0f);  // Ensure scale never goes below 0.2
            this.sprite.resize((int)(originalWidth * scale), (int)(originalHeight * scale));
        }
        else {
            // isBeingCaptured flag becomes false
            isBeingCaptured = false;
        }
    }

    /**
     * Checks if the ball is close enough to a hole to be captured.
     *
     * @param hole The hole to check for capture.
     * @return {@code true} if the ball should be captured by the hole; otherwise, {@code false}.
     */
    private boolean shouldCaptureBall(Hole hole) {
        // Calculate centre of ball and hole
        float holeCenterX = hole.getX() + 32;
        float holeCenterY = hole.getY() + 32;
        float ballCenterX = this.x + this.sprite.width / 2;
        float ballCenterY = this.y + this.sprite.height / 2;
        
        float distance = PApplet.dist(ballCenterX, ballCenterY, holeCenterX, holeCenterY);

        // return true if distance of ball is < capture threshold. 
        return distance < CAPTURE_THRESHOLD;
    }

    /**
     * Handles collisions with walls and line segments.
     *
     * @param lines The list of line segments for collision detection.
     */
    private void handleCollisions(ArrayList<ArrayList<float[]>> lines) {
        // Check collisions with lines and walls 
        checkWallCollisions(); 
        checkLineCollisions(lines);
    }

    /**
     * Checks for collisions with walls and resolves any detected collisions.
     */
    private void checkWallCollisions() {
        for (Wall wall : walls) {
            if (isCollidingWithWall(wall)) {
                resolveWallCollision(wall);
            }
        }
    }

    /** 
     * Checks whether the area of the ball is overlapping with the area of 
     * the wall. If so, returns true 
     * 
     * @param Wall the wall being used to check collision
     */
    private boolean isCollidingWithWall(Wall wall) {
        // Dimensions of a wall + ball
        float wallLeft = wall.getX();
        float wallRight = wall.getX() + wall.getWidth();
        float wallTop = wall.getY();
        float wallBottom = wall.getY() + wall.getHeight();

        float ballRight = this.x + this.getWidth();
        float ballBottom = this.y + this.getHeight();

        // Check if the ball's sprite area overlaps with the wall's sprite area
        return ballRight > wallLeft && this.x < wallRight && ballBottom > wallTop && this.y < wallBottom;
    }

    /**
     * Resolves collision between the ball and a wall object. Adjusts the ball's position based on 
     * overlap with the wall and reflects its velocity. If the wall has a specific color, 
     * changes the ball's sprite to match the wall.
     *
     * @param wall the Wall object the ball collides with
     */
    private void resolveWallCollision(Wall wall) {
        // Wall dimension
        float wallLeft = wall.getX();
        float wallRight = wall.getX() + wall.getWidth();
        float wallTop = wall.getY();
        float wallBottom = wall.getY() + wall.getHeight();
    
        // Calculate overlaps in each direction
        float overlapLeft = wallRight - this.x;
        float overlapRight = this.x + this.getWidth() - wallLeft;
        float overlapTop = wallBottom - this.y;
        float overlapBottom = this.y + this.getHeight() - wallTop;
    
        // Find the minimum overlap
        float minOverlap = Math.min(Math.min(overlapLeft, overlapRight), Math.min(overlapTop, overlapBottom));
    
        // Determine normal vector based on collision side
        PVector normal = new PVector(0, 0);
        
        // Adjust position and set normal direction based on the collision side
        if (minOverlap == overlapLeft) { 
            normal.set(1, 0);
            this.x = wallRight; // Move the ball to the right edge of the wall
        } else if (minOverlap == overlapRight) {
            normal.set(-1, 0);
            this.x = wallLeft - this.getWidth(); // Move the ball to the left edge of the wall
        } else if (minOverlap == overlapTop) {
            normal.set(0, 1);
            this.y = wallBottom; // Move the ball to the bottom edge of the wall
        } else if (minOverlap == overlapBottom) {
            normal.set(0, -1);
            this.y = wallTop - this.getHeight(); // Move the ball to the top edge of the wall
        }
    
        // Change ball color based on wall color
        String wallSpritePath = wall.getSpritePath();
        if (!wallSpritePath.equals("src/main/resources/inkball/wall0.png")) {  // If not a plain/grey wall
            String newBallSpritePath = convertWallSpriteToBallSprite(wallSpritePath);
            this.setSpritePath(newBallSpritePath);
            // Load and set the new sprite
            this.sprite = app.loadImage(newBallSpritePath);
            // Restore original dimensions as loading new image might change them
            this.sprite.resize((int)originalWidth, (int)originalHeight);
            this.originalSprite = app.loadImage(newBallSpritePath);
            this.originalSprite.resize((int)originalWidth, (int)originalHeight);
        }
    
        // Normalize the normal vector and reflect
        normal.normalize();
        reflect(normal);
    }

    /**
     * Converts a wall's sprite path to the corresponding ball sprite path based on wall color.
     *
     * @param wallSpritePath the file path of the wall sprite
     * @return the file path of the corresponding ball sprite
     */
    private String convertWallSpriteToBallSprite(String wallSpritePath) {
        // Convert wall sprite path to corresponding ball sprite path
        switch (wallSpritePath) {
            case "src/main/resources/inkball/wall1.png":  // Orange wall
                return "src/main/resources/inkball/ball1.png";
            case "src/main/resources/inkball/wall2.png":  // Blue wall
                return "src/main/resources/inkball/ball2.png";
            case "src/main/resources/inkball/wall3.png":  // Green wall
                return "src/main/resources/inkball/ball3.png";
            case "src/main/resources/inkball/wall4.png":  // Yellow wall
                return "src/main/resources/inkball/ball4.png";
            default:
                return this.getSpritePath();  // Return current sprite path if no match
        }
    }

    /**
     * Reflects the ball's velocity based on the given normal vector. Uses reflection formula to
     * adjust ball's speed and slightly adjusts the position to prevent sticking to walls.
     *
     * @param normal the normal vector indicating the collision side
     */
    private void reflect(PVector normal) {
        PVector velocity = new PVector(this.xspeed, this.yspeed);
        
        // Calculate the reflection using the formula: Velocity' = Velocity - 2 * (Velocity ⋅ Normal) * Normal
        float dotProduct = velocity.dot(normal);
        PVector reflectedVelocity = velocity.copy().sub(normal.copy().mult(2 * dotProduct));

        // Update ball's speed
        this.xspeed = reflectedVelocity.x;
        this.yspeed = reflectedVelocity.y;

        // Update position to ensure ball does not get stuck in the wall
        this.x += normal.x * 0.1; // Adjust position slightly along the normal
        this.y += normal.y * 0.1; // Adjust position slightly along the normal
    }

    /**
     * Checks for collisions between the ball and a list of drawn lines. If a collision is detected,
     * the ball reflects off the line's normal vector, and the line is removed from the list.
     *
     * @param lines a list of lines, each represented as an ArrayList of float arrays (each float array represents a point)
     */
    private void checkLineCollisions(ArrayList<ArrayList<float[]>> lines) {
        for (int lineIndex = 0; lineIndex < lines.size(); lineIndex++) {
            ArrayList<float[]> line = lines.get(lineIndex);
            for (int i = 0; i < line.size() - 1; i++) {
                if (lineIntersectsBall(line.get(i), line.get(i + 1))) {
                    // Get normal vector for the line
                    PVector normal = calculateNormal(line.get(i), line.get(i + 1));
    
                    // Reflect the ball based on the line's normal
                    reflect(normal);
    
                    // Move the ball slightly outside the line
                    this.x += normal.x * 0.1;
                    this.y += normal.y * 0.1;
    
                    // Remove the entire line from the list
                    lines.remove(lineIndex);
                    lineIndex--;  // Adjust index after removal
    
                    // Exit after first collision
                    return;
                }
            }
        }
    }  

    /**
     * Calculates the normal vector of a line segment defined by two points. 
     * The normal vector is perpendicular to the line direction.
     *
     * @param p1 the starting point of the line segment
     * @param p2 the ending point of the line segment
     * @return a normalized PVector representing the normal to the line
     */
    private PVector calculateNormal(float[] p1, float[] p2) {
        // Calculate the direction vector of the line
        PVector lineDirection = new PVector(p2[0] - p1[0], p2[1] - p1[1]);
        // Get a normal vector (perpendicular) by swapping x and y and negating one
        PVector normal = new PVector(-lineDirection.y, lineDirection.x);
        normal.normalize(); // Normalize the normal vector
        return normal;
    }

    /**
     * Checks if a line segment intersects the ball by calculating the distance 
     * from the ball's center to the line segment and comparing it to the ball's radius.
     *
     * @param p1 the starting point of the line segment
     * @param p2 the ending point of the line segment
     * @return true if the line intersects the ball, false otherwise
     */
    private boolean lineIntersectsBall(float[] p1, float[] p2) {
        // Calculate ball center position
        float ballCenterX = this.x + this.getWidth() / 2;
        float ballCenterY = this.y + this.getHeight() / 2;

         // Calculate the shortest distance from the ball center to the line segment
        float distance = pointToSegmentDistance(ballCenterX, ballCenterY, p1[0], p1[1], p2[0], p2[1]);

        // Return true if the distance is less than or equal to the ball's radius
        return distance <= this.getWidth() / 2;
    }

    /**
     * Calculates the shortest distance between a point and a line segment.
     *
     * @param px the x-coordinate of the point
     * @param py the y-coordinate of the point
     * @param x1 the x-coordinate of the first point of the segment
     * @param y1 the y-coordinate of the first point of the segment
     * @param x2 the x-coordinate of the second point of the segment
     * @param y2 the y-coordinate of the second point of the segment
     * @return the shortest distance from the point to the line segment
     */
    private float pointToSegmentDistance(float px, float py, float x1, float y1, float x2, float y2) {
        float l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);  // Calculate the square of the length of the segment

        // If the segment length is zero, return distance from the point to one of the segment points
        if (l2 == 0) return dist(px, py, x1, y1);

         // Project point onto the line, clamping t to the [0, 1] range
        float t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
        t = Math.max(0, Math.min(1, t));

        // Calculate the closest point on the segment to (px, py)
        return dist(px, py, x1 + t * (x2 - x1), y1 + t * (y2 - y1));
    }

    /**
     * Calculates the distance between two points.
     *
     * @param x1 the x-coordinate of the first point
     * @param y1 the y-coordinate of the first point
     * @param x2 the x-coordinate of the second point
     * @param y2 the y-coordinate of the second point
     * @return the distance between the two points
     */
    private float dist(float x1, float y1, float x2, float y2) { //Calculate distance
        return (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    }
}
