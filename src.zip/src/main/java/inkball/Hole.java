package inkball;

import processing.core.PImage;

/**
 * The {@code Hole} class represents a hole in the Inkball game. It extends the {@code GameObject} 
 * class and provides functionality specific to a hole, such as its position and appearance.
 */
public class Hole extends GameObject {

    /**
     * Constructor for a {@code Hole} object with the specified image, position, and sprite path.
     *
     * @param sprite     the {@code PImage} representing the visual appearance of the hole
     * @param x          the x-coordinate of the hole's position
     * @param y          the y-coordinate of the hole's position
     * @param spritePath the file path to the sprite image used for the hole
     */
    public Hole(PImage sprite, float x, float y, String spritePath) {
        super(sprite, x, y, spritePath);
    }

}
