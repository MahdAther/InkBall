package inkball;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

/** 
 * The (@code GameLayout) class reads a txt file to produce the layout of a level. It creates 
 * all types of GameObject object's i.e. Wall, Ball, Spawner, Hole, and Tile, to create the layout 
 * provided
 */
public class GameLayout {
    /** Path for grey Wall */
    private String PlainWall = "src/main/resources/inkball/wall0.png";

    /** Path for orange Wall */
    private String OrangeWall = "src/main/resources/inkball/wall1.png";

    /** Path for blue Wall */
    private String BlueWall = "src/main/resources/inkball/wall2.png";

    /** Path for green Wall */
    private String GreenWall = "src/main/resources/inkball/wall3.png";

    /** Path for yellow Wall */
    private String YellowWall = "src/main/resources/inkball/wall4.png";

    /** Path for grey Ball */
    private String GreyBall = "src/main/resources/inkball/ball0.png";

    /** Path for orange Ball */
    private String OrangeBall = "src/main/resources/inkball/ball1.png";

    /** Path for blue Ball */
    private String BlueBall = "src/main/resources/inkball/ball2.png";

    /** Path for green Ball */
    private String GreenBall = "src/main/resources/inkball/ball3.png";

    /** Path for yellow Ball */
    private String YellowBall = "src/main/resources/inkball/ball4.png";

    /** Path for spawner */
    private String Spawner = "src/main/resources/inkball/entrypoint.png";

    /** Path for grey Hole*/
    private String PlainHole = "src/main/resources/inkball/hole0.png";

    /** Path for orange Hole */
    private String OrangeHole = "src/main/resources/inkball/hole1.png";

    /** Path for blue Hole */
    private String BlueHole = "src/main/resources/inkball/hole2.png";

    /** Path for green Hole */
    private String GreenHole = "src/main/resources/inkball/hole3.png";

    /** Path for yellow Hole */
    private String YellowHole = "src/main/resources/inkball/hole4.png";

    /** Path for background tiles */
    private String tiles = "src/main/resources/inkball/tile.png";  

    /** List of walls, to hold all wall objects */
    private ArrayList<Wall> walls = new ArrayList<Wall>();  

    /** List of balls, to hold all ball objects */
    private ArrayList<Ball> balls = new ArrayList<Ball>();

    /** List of spawner, to hold all spawner objects */
    private ArrayList<Spawner> spawners = new ArrayList<Spawner>(); 

    /** List of holes, to hold all hole objects */
    private ArrayList<Hole> holes = new ArrayList<Hole>();

    /** List of tile, to hold all tile objects */
    private ArrayList<Tile> tileObjects = new ArrayList<Tile>(); 

    /** Instance PApplet to draw objects in app */
    private PApplet app;

    /**
     * Loads the layout from a specified text file and initialises the game objects
     * (Wall, Ball, Spawner, Hole, and Tile) based on the file content.
     * 
     * @param filename The path to the text file containing the level layout.
     * @param app The PApplet instance used to draw the game objects.
     */
    public void loadLayout(String filename, PApplet app) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line; // Each line has become a string
            int y = 2; // Y-coordinate starts at 2 and increments by 32 each row
            while ((line = reader.readLine()) != null) {
                for (int x = 0; x < line.length(); x++) {
                    char tile = line.charAt(x); // Checks what character is at x
                    int xPos = x * 32; // Each tile is 32 pixels wide
                    int yPos = y * 32; // Each tile is 32 pixels tall

                    PImage image = null; // Placeholder for the image

                    switch (tile) { // uses character from variable time for switch case
                        case 'X': // Plain wall
                            image = app.loadImage(PlainWall); // load image
                             // create new wall object and add it to walls
                            walls.add(new Wall(image, xPos, yPos, PlainWall));
                            break;
                        case '1': // Orange wall
                            image = app.loadImage(OrangeWall);
                            walls.add(new Wall(image, xPos, yPos, OrangeWall));
                            break;
                        case '2': // Blue wall
                            image = app.loadImage(BlueWall); 
                            walls.add(new Wall(image, xPos, yPos, BlueWall));
                            break;
                        case '3': // Green wall
                            image = app.loadImage(GreenWall);
                            walls.add(new Wall(image, xPos, yPos, GreenWall));
                            break;
                        case '4': // Yellow wall
                            image = app.loadImage(YellowWall);
                            walls.add(new Wall(image, xPos, yPos, YellowWall));
                            break;
                        case 'B': // Balls
                            char ballType = line.charAt(++x); // Get the next character for ball type
                            switch (ballType) {
                                case '0':
                                    image = app.loadImage(GreyBall); // Loads image of the ball
                                    balls.add(new Ball(image, xPos, yPos,GreenBall ,walls, holes, app)); //Add new ball to balls
                                    image = app.loadImage(tiles); // load image of tile
                                    tileObjects.add(new Tile(image, xPos, yPos, tiles)); // Add new tile to tiles for ball background
                                    // Add new tile with + 32 pixels in x direction to tiles to cover ball background
                                    tileObjects.add(new Tile(image, xPos + 32, yPos, tiles)); 
                                    break;
                                case '1':
                                    image = app.loadImage(OrangeBall);
                                    balls.add(new Ball(image, xPos, yPos, OrangeBall ,walls, holes, app));
                                    image = app.loadImage(tiles);
                                    tileObjects.add(new Tile(image, xPos, yPos, tiles));
                                    tileObjects.add(new Tile(image, xPos + 32, yPos, tiles));
                                    break;
                                case '2':
                                    image = app.loadImage(BlueBall);
                                    balls.add(new Ball(image, xPos, yPos, BlueBall ,walls, holes, app));
                                    image = app.loadImage(tiles);
                                    tileObjects.add(new Tile(image, xPos, yPos, tiles));
                                    tileObjects.add(new Tile(image, xPos + 32, yPos, tiles));
                                    break;
                                case '3':
                                    image = app.loadImage(GreenBall);
                                    balls.add(new Ball(image, xPos, yPos, GreenBall, walls, holes, app));
                                    image = app.loadImage(tiles);
                                    tileObjects.add(new Tile(image, xPos, yPos, tiles));
                                    tileObjects.add(new Tile(image, xPos + 32, yPos, tiles));
                                    break;
                                case '4':
                                    image = app.loadImage(YellowBall);
                                    balls.add(new Ball(image, xPos, yPos, YellowBall ,walls, holes, app));
                                    image = app.loadImage(tiles);
                                    tileObjects.add(new Tile(image, xPos, yPos, tiles));
                                    tileObjects.add(new Tile(image, xPos + 32, yPos, tiles));
                                    break;
                            }
                            break;
                        case 'S': // Spawner
                            image = app.loadImage(Spawner); // Load image of spawner 
                            spawners.add(new Spawner(image, xPos, yPos, Spawner)); // Add new spawner to spawners list
                            break;
                        case 'H': // Holes
                            char holeType = line.charAt(++x); // Get the next character for hole type
                            switch (holeType) {
                                case '0':
                                    image = app.loadImage(PlainHole); // Load image of the hole
                                    holes.add(new Hole(image, xPos, yPos, PlainHole)); // Add hole to holes
                                    break;
                                case '1':
                                    image = app.loadImage(OrangeHole);
                                    holes.add(new Hole(image, xPos, yPos, OrangeHole));
                                    break;
                                case '2':
                                    image = app.loadImage(BlueHole);
                                    holes.add(new Hole(image, xPos, yPos, BlueHole));
                                    break;
                                case '3':
                                    image = app.loadImage(GreenHole);
                                    holes.add(new Hole(image, xPos, yPos, GreenHole));
                                    break;
                                case '4':
                                    image = app.loadImage(YellowHole);
                                    holes.add(new Hole(image, xPos, yPos, YellowHole));
                                    break;
                            }
                            break;
                           case ' ': // White space - create a tile
                           image = app.loadImage(tiles); // Load image of tile
                           tileObjects.add(new Tile(image, xPos, yPos, tiles)); // Add tile to tiles
                           break;
                        default:
                            // Handle other characters or ignore them
                            break;
                    }
                }
                y++; // Move to the next row
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

     /**
     * Draws the entire layout on the provided PApplet. The method first draws the tiles, 
     * followed by walls, balls, spawners, and finally the holes.
     * 
     * @param app The PApplet instance used to render the game objects.
     */
    public void drawLayout(PApplet app) {
        // Step 1: Draw all tiles first
      for (Tile tile : tileObjects) {
        tile.draw(app);
        }

        // Step 2: Draw all walls
        for (Wall wall : walls) {
            wall.draw(app);
        }

        // Step 3: Draw all balls
        for (Ball ball : balls) {
            ball.draw(app);
        }

        // Step 4: Draw all spawners
        for (Spawner spawner : spawners) {
            spawner.draw(app);
        }

        // Step 5: Draw all holes
        for (Hole hole : holes) {
            hole.draw(app);
        }
    }

    /**
     * Getter of the list of walls in the level
     * 
     * @return ArrayList of walls of the level
     */
    public ArrayList<Wall> getWalls() { // getter for walls
        return walls;
    }

    /**
     * Getter of the list of balls in the level
     * 
     * @return ArrayList of balls of the level
     */
    public ArrayList<Ball> getBalls() { // getter for balls
        return balls;
    }

    /**
     * Getter of the list of spawner in the level
     * 
     * @return ArrayList of spawner of the level
     */
    public ArrayList<Spawner> getSpawners() { // getter for spawners
        return spawners;
    }

    /**
     * Getter of the list of holes in the level
     * 
     * @return ArrayList of holes of the level
     */
    public ArrayList<Hole> getHoles() { // getter for holes
        return holes;
    }
    
    /**
     * Getter of the list of tiles in the level
     * 
     * @return ArrayList of tiles of the level
     */
    public ArrayList<Tile> getTiles() { // getter for tiles
        return tileObjects;
    }
}
