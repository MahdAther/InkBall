package inkball;

import java.util.Random;

/**
 * The {@code BallVelocity} class is responsible for generating random velocity values
 * for a ball in the Inkball game. It provides an inner class {@code Pair} to hold the 
 * velocity components along the x and y axes, as well as a method to assign random values 
 * for the ball's velocity.
 */
public class BallVelocity {

    /**
     * The {@code Pair} class is a simple data structure to hold two integer values, 
     * representing the x and y components of the ball's velocity.
     */
    public static class Pair {
        /**
         * The x component of the velocity.
         */
        public int x;

        /**
         * The y component of the velocity.
         */
        public int y;

        /**
         * Constructor for a {@code Pair} object with the specified x and y values.
         *
         * @param x the x component of the velocity
         * @param y the y component of the velocity
         */
        public Pair(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    /**
     * Assigns random velocity values for the ball. The x component is randomly 
     * assigned either -2 or 2, and the y component is randomly assigned -2 or 2 as well.
     *
     * @return a {@code Pair} object containing the x and y velocity components
     */
    public Pair assignRandomValues() {
        Random random = new Random();

        int x, y;

        // Randomly choose either -2 or 2 for x
        x = random.nextBoolean() ? -2 : 2;

        // Randomly choose either -2 or 2 for y
        y = random.nextBoolean() ? -2 : 2;

        // Return x and y as a Pair object
        return new Pair(x, y);
    }
}
