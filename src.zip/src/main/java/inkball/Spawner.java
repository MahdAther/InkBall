package inkball; 

import processing.core.PImage; 

/**
 * The {@code Spawner} class represents a spawner in the Inkball game. It extends the {@code GameObject} abstract
 * class and provides functionality specific to a spawner, such as its position and appearance.
 */
public class Spawner extends GameObject{ 

    /**
     * Constructor for a {@code Spawner} object with the specified image, position, and sprite path.
     *
     * @param sprite     the {@code PImage} representing the visual appearance of the spawner
     * @param x          the x-coordinate of the spawner's position
     * @param y          the y-coordinate of the spawner's position
     * @param spritePath the file path to the sprite image used for the spawner
     */
    public Spawner(PImage sprite, float x, float y, String spritePath){ 
        //Invoked GameObject construtor to create object Spawner. 
        super(sprite, x, y, spritePath); 
    }

}