package inkball;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 * The {@code LevelConfig} class is responsible for loading and managing level configurations
 * from a JSON file for the Inkball game. It holds the ball types and scoring configuration 
 * for all levels. It has an inner class  {@code Level}, to hold the level's specific values. 
 * 
 * <p>This class parses the following data from the JSON file:
 * <ul>
 *   <li>Levels configuration</li>
 *   <li>Score increase rules for capturing balls in the correct hole</li>
 *   <li>Score decrease rules for capturing balls in the wrong hole</li>
 * </ul>
 * 
 * It also maps ball colors to their corresponding image paths and provides methods to retrieve
 * this data for use in the game.
 */
public class LevelConfig {
    /** List of levels, level being an object here*/
    private List<Level> levels = new ArrayList<>();

    /** Map of string and int, string is path for ball and int is score increase value */
    private Map<String, Integer> scoreIncreaseFromHoleCapture = new HashMap<>();

    /** Map of string and int, string is path for ball and int is score decrease value */
    private Map<String, Integer> scoreDecreaseFromWrongHole = new HashMap<>();

    /** Grey Ball path */
    private String plainBallPath = "src/main/resources/inkball/ball0.png";
    
    /** Orange Ball path */
    private String orangeBallPath = "src/main/resources/inkball/ball1.png";

    /** Blue Ball path */
    private String blueBallPath = "src/main/resources/inkball/ball2.png";

    /** Green Ball path */
    private String greenBallPath = "src/main/resources/inkball/ball3.png";

    /** Yellow Ball path */
    private String yellowBallPath = "src/main/resources/inkball/ball4.png";

    /** String for colour */
    private String colour;

    /**Maps path of a ball to the colour it represents it */
    private Map<String, String> colorToPathMap = new HashMap<>();

    
    /**
     * Constructor to load the level configuration data from a specified JSON file.
     * 
     * @param jsonFilePath the path to the JSON file containing the level data.
     */
    public LevelConfig(String jsonFilePath) {
        try {
            // Open a file input stream to read the JSON configuration file. 
            FileInputStream fis = new FileInputStream(jsonFilePath); 
            JSONTokener tokener = new JSONTokener(fis); // Create a JSONTokener to parse the file content.
            // Initialize a JSONObject with the tokener to represent the entire JSON content.
            JSONObject jsonObject = new JSONObject(tokener);

            // Parse levels array
            JSONArray levelsArray = jsonObject.getJSONArray("levels");
            for (int i = 0; i < levelsArray.length(); i++) {
                JSONObject levelObject = levelsArray.getJSONObject(i); //Extract level's data as JSONObject
                // Create a new Level instance using data from the JSON object.
                // Each level includes layout, time limit, spawn interval, scoring modifiers, and balls.
                Level level = new Level(
                        levelObject.getString("layout"), 
                        levelObject.getInt("time"),
                        levelObject.getInt("spawn_interval"),
                        levelObject.getDouble("score_increase_from_hole_capture_modifier"),
                        levelObject.getDouble("score_decrease_from_wrong_hole_modifier"),
                        parseBalls(levelObject.getJSONArray("balls"))
                );
                levels.add(level);
            }

            // Parse score increase and decrease maps
            JSONObject scoreIncreaseObject = jsonObject.getJSONObject("score_increase_from_hole_capture");
            JSONObject scoreDecreaseObject = jsonObject.getJSONObject("score_decrease_from_wrong_hole");

            // Convert the JSON objects for scoring into maps for easy retrieval by color.
            scoreIncreaseFromHoleCapture = parseScoreMap(scoreIncreaseObject);
            scoreDecreaseFromWrongHole = parseScoreMap(scoreDecreaseObject);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Parses a {@link JSONArray} of balls and converts them to file paths corresponding
     * to their color.
     * 
     * @param ballsArray the JSON array containing the ball types.
     * @return an {@code ArrayList<String>} containing the file paths of the ball images.
     */
    private ArrayList<String> parseBalls(JSONArray ballsArray) {
        ArrayList<String> balls = new ArrayList<>();
        for (int i = 0; i < ballsArray.length(); i++) { //Iterate through balls for queue
            String ballType = ballsArray.getString(i);
            switch (ballType.toLowerCase()) {
                case "grey": // Adds that colour's ball path to ArrayList ballls 
                    balls.add(plainBallPath);
                    break;
                case "orange":
                    balls.add(orangeBallPath);
                    break;
                case "blue":
                    balls.add(blueBallPath);
                    break;
                case "green":
                    balls.add(greenBallPath);
                    break;
                case "yellow":
                    balls.add(yellowBallPath);
                    break;
                default:
                    System.out.println("Unknown ball type: " + ballType);
            }
        }
        return balls;
    }

    /**
     * Parses a {@link JSONObject} that contains score modification values.
     * 
     * @param scoreObject the JSON object containing the score values.
     * @return a {@code Map<String, Integer>} mapping color names to their corresponding score values.
     */
    private Map<String, Integer> parseScoreMap(JSONObject scoreObject) {
        Map<String, Integer> scoreMap = new HashMap<>(); // Hashmap for colour and score
        for (String key : scoreObject.keySet()) { // Iterate through keyset 
            scoreMap.put(key, scoreObject.getInt(key)); // put key of colour and int into hashmap
        }
        return scoreMap;
    }

    /**
     * Returns the list of levels loaded from the JSON file.
     * 
     * @return a {@code List<Level>} representing the levels in the game.
     */
    public List<Level> getLevels() { // getter for levels
        return levels;
    }

    /**
     * Converts the ball image path to the corresponding color name.
     * 
     * @param ballPath the file path of the ball image.
     * @return the color name of the ball, or {@code "unknown"} if the path is not recognized.
     */
    public String pathToName(String ballPath) { 
        if (plainBallPath.equals(ballPath)){ // If ball path = colour of ballpath return that colour
            return "grey";
        }
        else if(orangeBallPath.equals(ballPath)){ 
            return "orange";
        }
        else if(greenBallPath.equals(ballPath)){ 
            return "green";
        }
        else if(blueBallPath.equals(ballPath)){ 
            return "blue";
        }
        else if(yellowBallPath.equals(ballPath)){ 
            return "yellow";
        }
        return "unknown";  // Default case
    }

    /**
     * Retrieves the score increase from capturing a ball in the correct hole based on the color.
     * 
     * @param colour the color of the ball.
     * @return the score increase value, or 0 if the color is not recognized.
     */
    public int getScoreIncreaseFromHoleCapture(String colour) { // Use key of colour to get socre inc. value
        return scoreIncreaseFromHoleCapture.getOrDefault(colour.toLowerCase(), 0);
    }

    /**
     * Retrieves the score decrease from capturing a ball in the wrong hole based on the color.
     * 
     * @param color the color of the ball.
     * @return the score decrease value, or 0 if the color is not recognized.
     */
    public int getScoreDecreaseFromWrongHole(String color) {
        // Check if the map contains the color and if not, return a default value
        if (scoreDecreaseFromWrongHole.containsKey(color.toLowerCase())) {
            return scoreDecreaseFromWrongHole.get(color.toLowerCase());
        } else {
            return 0;
        }
    }

    /**
     * The {@code Level} class represents a single level in the game, 
     * holding data about the level's layout,
     * time limits, ball types, and scoring modifiers.
     */
    public static class Level {
        /** Layout of the level*/
        private String layout;

        /** Time value for timer in level */
        private int time;

        /** Value for spawnInterval */
        private int spawnInterval;

        /** Modifier for score increase */
        private double scoreIncreaseModifier;

        /** Modifier for score decrease */
        private double scoreDecreaseModifier;

        /** ArrayList for ball path string */
        private ArrayList<String> balls;

         /**
         * Constructs a new {@code Level} object with the specified parameters.
         * 
         * @param layout the layout of the level.
         * @param time the time limit for the level.
         * @param spawnInterval the interval at which balls spawn in the level.
         * @param scoreIncreaseModifier the modifier applied to the score when a ball is captured in the correct hole.
         * @param scoreDecreaseModifier the modifier applied to the score when a ball is captured in the wrong hole.
         * @param balls the list of ball image paths used in the level.
         */
        public Level(String layout, int time, int spawnInterval, double scoreIncreaseModifier,
                     double scoreDecreaseModifier, ArrayList<String> balls) { // Constructor for level
            this.layout = layout;
            this.time = time;
            this.spawnInterval = spawnInterval;
            this.scoreIncreaseModifier = scoreIncreaseModifier;
            this.scoreDecreaseModifier = scoreDecreaseModifier;
            this.balls = balls;
        }

        /**
         * Returns the layout of the level.
         * 
         * @return the layout as a {@code String}.
         */
        public String getLayout() {
            return layout;
        }

        /**
         * Returns the time limit for the level.
         * 
         * @return the time limit in seconds as an {@code int}.
         */
        public int getTime() {
            return time;
        }

        /**
         * Returns the interval at which balls spawn in the level.
         * 
         * @return the spawn interval in milliseconds as an {@code int}.
         */
        public int getSpawnInterval() {
            return spawnInterval;
        }

        /**
         * Returns the score increase modifier for capturing a ball in the correct hole.
         * 
         * @return the score increase modifier as a {@code double}.
         */
        public double getScoreIncreaseModifier() {
            return scoreIncreaseModifier;
        }

        /**
         * Returns the score decrease modifier for capturing a ball in the wrong hole.
         * 
         * @return the score decrease modifier as a {@code double}.
         */
        public double getScoreDecreaseModifier() {
            return scoreDecreaseModifier;
        }

        /**
         * Returns the list of ball image paths used in the level.
         * 
         * @return an {@code ArrayList<String>} containing the file paths of the balls.
         */
        public ArrayList<String> getBalls() {
            return balls;
        }
    }
}


