package inkball; 

import processing.core.PImage; 

/**
 * The {@code Wall} class represents a tile in the Inkball game. It extends the {@code GameObject} abstract
 * class and provides functionality specific to a wall, such as its position and appearance.
 */
public class Wall extends GameObject{ 

    /**
     * Constructor for a {@code Wall} object with the specified image, position, and sprite path.
     *
     * @param sprite     the {@code PImage} representing the visual appearance of the tile
     * @param x          the x-coordinate of the Wall's position
     * @param y          the y-coordinate of the Wall's position
     * @param spritePath the file path to the sprite image used for the tile
     */

    public Wall(PImage sprite, float x, float y, String spritePath){ 
        //Invoked GameObject construtor to create object Tile. 
        super(sprite, x, y, spritePath);
    }

}