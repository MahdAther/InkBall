package inkball;


import java.util.ArrayList;
import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;
import processing.event.KeyEvent;
import processing.event.MouseEvent; 


public class App extends PApplet {

    public static final int CELLSIZE = 32; // Size of a cell
    public static final int CELLHEIGHT = 32; // Height of cell 
    public static final int CELLAVG = 32; // Value of Cellavg

    public static final int TOPBAR = 64; // Y-coord of TopBar
    public static int WIDTH = 576;  // Width; CELLSIZE*BOARD_WIDTH
    public static int HEIGHT = 640; // Height; BOARD_HEIGHT*CELLSIZE+TOPBAR

    public static final int BOARD_WIDTH = WIDTH/CELLSIZE; //Board width
    public static final int BOARD_HEIGHT = 20; // Board height


    private static final int SPAWNBAR_X = 10; //Spawnbar x-coord
    private static final int SPAWNBAR_Y = 10; //Spawnbar y-coord
    private static final int SPAWNBAR_WIDTH = 180; //Spawnbar width
    private static final int SPAWNBAR_HEIGHT = 40; // Spawner height
    private static final int BALL_SPACING = 36; // Spacing between balls(px)
    private static final int MAX_VISIBLE_BALLS = 5; // Balls shown

    public static final int INITIAL_PARACHUTES = 1;

    private String currentLevelPathString; // Current level string

    public static final int FPS = 30; // Fps for game

    public String configPath; //Path for config file

    public static Random random = new Random(); //For random values

    private ArrayList<Wall> walls; //ArrayList of Wall object
    private ArrayList<Ball> levelballs; //ArrayList of Ball object in level
    private ArrayList<Hole> holes; //Arraylist of Hole object

    private ArrayList<Spawner> spawners;  // List to store spawners
    private ArrayList<Ball> spawnerballs;  // List to store spawned balls
    private long lastSpawnTime;             // To keep track of time since last spawn
    private int SPAWN_INTERVAL; // Spawn interval in milliseconds

    private GameLayout gameLayout; //Instiate Gamelayout to create layout for level

    private ArrayList<ArrayList<float[]>> lines;  // List to store multiple lines
    private ArrayList<float[]> currentLine;       // Store the currently drawn line

    private boolean drawingLine = false;  // Track if a line is being drawn
    private boolean ctrlPressed = false;  // Track if ctrl button was pressed
    private boolean paused = false; // If paused 

    private int Initial_Time;  // Initial countdown time in seconds
    private int timeRemaining = Initial_Time; // Timer variable
    private long lastTimeCheck; // For checking elapsed time
    private boolean timeUp = false; // Flag for timeup 

    private int currentBallIndex = 0; //Index for ball in spawnbar

    private LevelConfig levelConfig; // Config for level 

    private boolean correctCapture; // Flag for correct capture 
    private int score = 0; //score value 

    private ArrayList<Ball> scoredBalls; //Arraylist of balls that have been socre
    private ArrayList<String> configballs; //ArrayList of strin of ballpath waiting to be spawned

    private ArrayList<PImage> queuedBallImages; // Images shown in spawnbar 
    private ArrayList<String> queuedBallPaths; //String path for ball in spawnbar 

    private long pauseStartTime = 0;    // Track when pause starts
    private long totalPauseTime = 0;    // Accumulate total pause time
    private long adjustedLastSpawnTime; // Track spawn time accounting for pauses

    private boolean isSpawningActive = true; // Track if spawning system is active
    private boolean wasSpawningActive = true; // Track previous spawn state for resuming
    private long timeWhenSpawningPaused = 0; // Track when spawning was paused
    private long totalSpawnPauseTime = 0; // Track total time spawning was paused
    private long lastWrongHoleTime = 0; // Last time ball went into wrong hole

    private float spawnCountdownValue = 0; // spawn count down value

    private boolean levelCompleted = false; // Flag for level complete 
    private boolean bonusScoreAdded = false; // Flag for bonus scored added
    private float bonusScore = 0; // Bonus scored added 
    private boolean bonusPhaseActive = false; // Flag for bonus phase active 
    private long lastBonusUpdate = 0; // When last bonus score was added
    private static final float BONUS_TIME_DECREMENT = 0.067f; // Time decrement during bonus
    private static final int BONUS_UPDATE_INTERVAL = 67; // 0.067 seconds in milliseconds


    private Wall topLeftWall; // Wall for top left in bonus 
    private Wall bottomRightWall; // Wall for bottom right in bonus
    private PImage yellowWallImage; // Yellow wall image 
    private int wallPosition = 0; // 0: top, 1: right, 2: bottom, 3: left
    private long lastWallMove = 0; //Int wall move
    private static final int WALL_SIZE = 32; // wall size (px)
    private static final int WALL_MOVE_INTERVAL = 67; 

    private int currentLevelIndex = 0; //index for current level
    private boolean transitioningToNextLevel = false; // flag for transition 
    private static final int LEVEL_TRANSITION_DELAY = 500; //delay between level transition
    private long levelCompleteTime = 0; // Time when level has been complete 
    private boolean gameCompleted = false; // Flag for game complete

    /**
     * Constructs an instance of the App class, initializing game settings and
     * various game elements such as walls, balls, spawners, lines, and score-tracking lists.
     * Sets the configuration file path and initializes spawn timing.
     */
    public App() {
        this.configPath = "config.json"; //config file for levels 
        // Instantiate Arraylist for Game
        this.lines = new ArrayList<>();
        this.currentLine = new ArrayList<>(); 
        this.scoredBalls = new ArrayList<>();
        this.queuedBallImages = new ArrayList<>(); 
        this.queuedBallPaths = new ArrayList<>();
        this.adjustedLastSpawnTime = millis();
    }

    /**
     * Sets the display size of the game window according to the configured WIDTH and HEIGHT constants.
     */
    public void settings() {
        size(WIDTH, HEIGHT); //Size of App
    }

    /**
     * Initializes game settings, loads level configuration, and prepares game elements
     * such as walls, balls, spawners, and scoring. Sets up the ball queue for the spawn bar
     * and loads the necessary level layout from the specified configuration file.
     * 
     * Initializes various objects and properties like the game layout, wall and ball lists, 
     * spawn time, pause tracking, and level configuration. Also sets up the dynamic walls for the bonus phase.
     */
    @Override
    public void setup() {
        frameRate(FPS); // Framerate 
        gameLayout = new GameLayout(); // Initialise the layout for the level
        gameLayout.loadLayout("level1.txt", this);// Load specific level layout

        // Walls, Balls and holes from layout being intialise
        this.walls = gameLayout.getWalls(); 
        this.levelballs = gameLayout.getBalls();
        this.holes = gameLayout.getHoles();
        this.spawners = gameLayout.getSpawners();

        this.spawnerballs = new ArrayList<>(); // Initialize ball list
        this.lastSpawnTime = millis();         // Initialize spawn time

        this.adjustedLastSpawnTime = millis(); // Track initial time accounting for any pauses
        this.totalPauseTime = 0; // Initialise pause time

        lastTimeCheck = millis(); // The last time check for countdown 

        this.levelConfig = new LevelConfig(configPath); // Config for balls and scoring for level
        this.configballs = levelConfig.getLevels().get(currentLevelIndex).getBalls(); // Balls in queue

        initializeBallQueue(); 

        // Set specific configurations from the loaded level data
        if (!levelConfig.getLevels().isEmpty()) {
            LevelConfig.Level currentLevel = levelConfig.getLevels().get(currentLevelIndex);

            // Set the spawn interval from the level configuration
            this.SPAWN_INTERVAL = currentLevel.getSpawnInterval() * 1000;
            
            // Set the time remaining for the level
            this.timeRemaining = currentLevel.getTime();
            this.Initial_Time = this.timeRemaining;
        }

        // Load and position dynamic walls for the bonus phase
        yellowWallImage = loadImage("src/main/resources/inkball/wall4.png");
        topLeftWall = new Wall(yellowWallImage, 0, TOPBAR, "src/main/resources/inkball/wall4.png");
        bottomRightWall = new Wall(yellowWallImage, WIDTH - WALL_SIZE, HEIGHT - WALL_SIZE, "src/main/resources/inkball/wall4.png");
    }

    /**
     * Initialises the ball queue by clearing any existing items and loading the first 
     * set of ball images from the configuration. Ensures that the maximum number of 
     * balls visible in the spawn bar is set up for display.
     * <p>
     * Resets the current ball index to zero and loads up to {@code MAX_VISIBLE_BALLS} 
     * ball images into the spawn bar, resizing each image to fit.
     */
    private void initializeBallQueue() {
        // Clear existing queues
        queuedBallImages.clear();
        queuedBallPaths.clear();
        
        // Reset current ball index
        currentBallIndex = 0;
    
        // Load the first MAX_VISIBLE_BALLS images
        for (int i = 0; i < Math.min(MAX_VISIBLE_BALLS, configballs.size()); i++) {
            String ballPath = configballs.get(i);
            PImage ballImage = loadImage(ballPath);
            ballImage.resize(32, 32);
            queuedBallImages.add(ballImage); // Add resized image to image queue
            queuedBallPaths.add(ballPath); // Add to the path queue
        }
    }

    /**
     * Updates the ball queue by removing the first ball image and adding the next 
     * ball image in the configuration, if available. Ensures that the maximum number
     * of balls visible in the spawn bar is maintained.
     * 
     * Removes the first ball from the front of the queue and checks if there is a 
     * next ball available in the configuration list. If available, loads the next ball 
     * image, resizes it, and adds it to the queue.
     */
    private void updateBallQueue() {
        if (currentBallIndex < configballs.size()) {
            // Remove the first ball from the queue
            if (!queuedBallImages.isEmpty()) {
                queuedBallImages.remove(0);
                queuedBallPaths.remove(0);
            }
    
            // Add the next ball if available
            int nextBallIndex = currentBallIndex + MAX_VISIBLE_BALLS;
            if (nextBallIndex < configballs.size()) {
                String nextBallPath = configballs.get(nextBallIndex);
                PImage nextBallImage = loadImage(nextBallPath);
                nextBallImage.resize(32, 32);
                queuedBallImages.add(nextBallImage); // Add resized image to image queue
                queuedBallPaths.add(nextBallPath); // Add to the path queue
            }
        }
    }

    /**
     * Draws the spawn bar on the screen, displaying a black background bar and overlaying 
     * the queued ball images in a row with defined spacing.
     * 
     * Loops through the ball images in the queue and draws each image in the spawn bar, 
     * ensuring each is positioned horizontally with even spacing.
     */
    private void drawSpawnBar() {
        // Draw the solid black background bar
        noStroke();
        fill(0);
        rect(SPAWNBAR_X, SPAWNBAR_Y, SPAWNBAR_WIDTH, SPAWNBAR_HEIGHT);

        // Draw the queued balls
        for (int i = 0; i < queuedBallImages.size(); i++) {
            PImage ballImage = queuedBallImages.get(i);
            // Calculate position for each ball, centered vertically in the bar
            float x = SPAWNBAR_X + 4 + (i * BALL_SPACING);
            float y = SPAWNBAR_Y + (SPAWNBAR_HEIGHT - ballImage.height) / 2;
            image(ballImage, x, y);
        }
    }

    /**
     * Updates the game timer by decreasing the remaining time by 1 second every second.
     * 
     * Ensures the countdown doesn't go below zero. When the timer reaches zero, 
     * the {@code timeUp} flag is set to indicate that time has run out. 
     */
    public void updateTimer() {
        // Decrease timer by 1 second every 1000 milliseconds (1 second)
        if (!timeUp && millis() - lastTimeCheck >= 1000) {
            timeRemaining--;
            lastTimeCheck = millis();
        }

        // If the time runs out, trigger level failure or timeout logic
        if (timeRemaining <= 0) {
            timeRemaining = 0;  // Ensure timer doesn't go negative
            timeUp = true;      // Mark time as up
        }
    }

    /**
     * Draws the timer countdown in the top-right corner of the screen, displaying 
     * the remaining time in seconds.
     */
    public void drawTimer() {
        fill(0);  // Set the text color
        textSize(20);  // Set text size
        textAlign(RIGHT, TOP);  // Align text to the top-right corner
        text("Time: " + timeRemaining, WIDTH - 10, 10);  // Display time in top-right corner
    }

    /**
     * Displays the countdown timer for the next ball spawn in the spawn bar area.
     * 
     * Calculates the remaining time until the next ball spawn while accounting 
     * for any paused game state. Displays the countdown in seconds to one decimal 
     * place, or the stored countdown value if paused.
     */
    public void drawSpawnCountdown() {
        if (!timeUp && !paused) {
            if (!queuedBallImages.isEmpty() && isSpawningActive) {
                // Calculate elapsed time accounting for all pauses
                long currentTime = millis();
                long effectiveTime = currentTime - totalPauseTime - totalSpawnPauseTime;
                float elapsedTime = (effectiveTime - adjustedLastSpawnTime) / 1000.0f;
                
                 // Calculate time left until the next spawn
                float timeUntilNextSpawn = (SPAWN_INTERVAL / 1000.0f) - elapsedTime;
                
                // Reset the countdown for the next spawn if elapsed time has passed the interval
                if (timeUntilNextSpawn <= 0) {
                    timeUntilNextSpawn = SPAWN_INTERVAL / 1000.0f;
                    adjustedLastSpawnTime = effectiveTime;
                }
                
                // Text settings
                fill(0);
                textSize(20);
                textAlign(LEFT, TOP);
                text(String.format("%.1f", timeUntilNextSpawn), 200, 25);
            }
        } else if (paused) {
            // Display the stored countdown value while paused
            fill(0);
            textSize(20);
            textAlign(LEFT, TOP);
            text(String.format("%.1f", spawnCountdownValue), 200, 25);
        }
    }   

    /**
     * Checks and updates the spawning state based on the availability of queued ball images.
     * 
     * If there are no queued ball images, spawning is paused; otherwise, spawning is resumed. 
     * Adjusts the timing to account for any pauses in the spawning process.
     */
    private void checkAndUpdateSpawningState() {
        // Determine if spawning should be active based on the no. of queued balls
        boolean shouldBeActive = !queuedBallImages.isEmpty();
        
        // If game should be active but spawning is not, spawning state is updated
        if (shouldBeActive != isSpawningActive) {
            if (shouldBeActive) {
                // Resume spawning
                totalSpawnPauseTime += (millis() - timeWhenSpawningPaused); // Update total paused time
                adjustedLastSpawnTime = millis() - totalPauseTime - totalSpawnPauseTime; // Adjust last spawn time
            } else {
                // Pause spawning
                timeWhenSpawningPaused = millis();
            }
            isSpawningActive = shouldBeActive; // Update the spawning state
        }
    }
    
    /**
     * Spawns balls from the spawners if spawning is active and the game is not paused or over.
     * 
     * This method checks the elapsed time since the last ball spawn and creates a new ball 
     * if the appropriate time interval has passed. The new ball is positioned at a random 
     * spawner, and its colour is based on level config ball list. 
     */
     public void spawnBallsFromSpawners() {
        checkAndUpdateSpawningState();
        
        // Only proceed with spawning if the game is active and not paused
        if (isSpawningActive && !timeUp && !paused) {
            // Calculate effective game time accounting for all pauses
            long currentTime = millis();
            long effectiveTime = currentTime - totalPauseTime - totalSpawnPauseTime;
            
            // Calculate elapsed time relative to the game timer
            int elapsedTime = Initial_Time - timeRemaining;
            
            // Check if the elapsed time has reached the spawn interval for the next ball
            if (elapsedTime >= (currentBallIndex + 1) * SPAWN_INTERVAL / 1000) {
                String ballImagePath = configballs.get(currentBallIndex);  // Get the path of the next ball image
                Spawner randomSpawner = spawners.get((int) random(spawners.size())); // Select a random spawner
                PImage image = loadImage(ballImagePath);
                 // Create a new ball object at the random spawner's position
                Ball newBall = new Ball(image, randomSpawner.getX(), randomSpawner.getY(), 
                                      ballImagePath, walls, holes, this);
                spawnerballs.add(newBall);  // Add the new ball to the list of spawned balls
                
                updateBallQueue();  // Update the queue of ball images for the spawn bar
                currentBallIndex++;  // Move to the next ball index
                adjustedLastSpawnTime = effectiveTime;  // Update the adjusted spawn time
                
                // Check if we need to pause spawning after this spawn
                checkAndUpdateSpawningState();
            }
        }
    }    
    
    /**
     * Handles the event when a key is pressed on the keyboard.
     * 
     * This method checks which key was pressed to perform specific actions:
     * - If the space bar is pressed, it toggles the game's pause state. 
     *   If the game is not paused, it pauses the game and stores the current spawn countdown value.
     *   If the game is paused, it resumes the game and adjusts the spawn timer based on the 
     *   time elapsed during the pause.
     * - If 'R' is pressed, it resets the game to level 1 if the game was completed,
     *   or resets the current level if not.
     * - If the Control key is pressed, it sets the `ctrlPressed` flag to true.
     *
     * @param event the key event containing information about the key press
     */
	public void keyPressed(KeyEvent event) {
        if (event.getKey() == ' ') {
            if (!paused) {
                // Starting a pause
                pauseStartTime = millis();
                wasSpawningActive = isSpawningActive;
                isSpawningActive = false;
                
                // Store the current spawn countdown value
                long currentTime = millis();
                long effectiveTime = currentTime - totalPauseTime - totalSpawnPauseTime;
                float elapsedTime = (effectiveTime - adjustedLastSpawnTime) / 1000.0f;
                spawnCountdownValue = (SPAWN_INTERVAL / 1000.0f) - elapsedTime;
            } else {
                // Ending a pause
                totalPauseTime += millis() - pauseStartTime;
                isSpawningActive = wasSpawningActive;
                
                if (isSpawningActive) {
                    // Calculate new adjustedLastSpawnTime based on preserved countdown
                    long currentTime = millis();
                    adjustedLastSpawnTime = currentTime - totalPauseTime - totalSpawnPauseTime - 
                        (long)((SPAWN_INTERVAL / 1000.0f - spawnCountdownValue) * 1000);
                }
            }
            paused = !paused;
        }
    
        if (event.getKey() == 'r' || event.getKey() == 'R') {
            if (gameCompleted) {
                // Reset to level 1
                gameCompleted = false;
                currentLevelIndex = 0;
                resetGame();
            } else {
                // Normal level reset
                resetLevel();
            }
        }
        
        if (event.isControlDown()) {
            ctrlPressed = true;
        }
    }

    /**
     * Handles the event when a key is released on the keyboard.
     * 
     * This method checks if the released key is the Control key. If it is not,
     * the `ctrlPressed` flag is reset to false, indicating that Control is no longer held down.
     *
     * @param event the key event for the key release
     */
	@Override
    public void keyReleased(KeyEvent event) {
        if (!event.isControlDown()) {
            ctrlPressed = false;  // Reset when 'Ctrl' is released
        }
    }

    /**
     * Handles the event when a mouse button is pressed.
     * 
     * This method performs different actions based on which mouse button is pressed:
     * - If the left mouse button is pressed while holding down the Control key,
     *   all drawn lines will be cleared.
     * - If only the left mouse button is pressed, a new line drawing starts,
     *   and the initial point of the line is recorded.
     * - If the right mouse button is pressed, all drawn lines will be cleared.
     *
     * @param e the mouse event for mouse press
     */
    @Override
    public void mousePressed(MouseEvent e) {
        if (mouseButton == LEFT && ctrlPressed) {
            // Remove all lines if 'Ctrl' + left mouse button is pressed
            lines.clear();
        } else if (mouseButton == LEFT) {
            // Start drawing a new line if just the left mouse button is pressed
            currentLine = new ArrayList<>();
            drawingLine = true;
            currentLine.add(new float[]{mouseX, mouseY}); // Add the starting point of the new line
        } else if (mouseButton == RIGHT) {
            // Remove all lines if the right mouse button is pressed
            lines.clear();
        }
    }

    /**
     * Handles the event when the mouse is dragged while a button is pressed.
     * 
     * This method allows the user to add points to the currently drawn line while
     * dragging the mouse with the left button pressed. Each position of the mouse
     * during the drag is recorded to create a continuous line.
     *
     * @param e the mouse event for mouse drag
     */
    @Override
    public void mouseDragged(MouseEvent e) {
        if (mouseButton == LEFT && drawingLine) {
            currentLine.add(new float[]{mouseX, mouseY});  // Continue adding points to the current line
        }
    }

    /**
     * Handles the event when a mouse button is released.
     * 
     * This method stops the drawing process if the left mouse button was released while drawing a line.
     * If the current line is not empty, it adds the completed line to the list of lines for rendering.
     *
     * @param e the mouse event for mouse release
     */
    @Override
    public void mouseReleased(MouseEvent e) {
        if (mouseButton == LEFT && drawingLine) {
            drawingLine = false; // Stop drawing
            if (!currentLine.isEmpty()) {
                lines.add(currentLine); // Add the completed line to the list of lines
            }
        }
    }

    /**
     * Draws all stored lines on the canvas.
     * 
     * This method iterates through the list of lines and draws each line segment
     * connecting consecutive points. The line color is set to black and the stroke
     * weight is set to 10 units for visibility. If the line is currently being 
     * drawn, it is drawn in real-time. 
     */
    public void drawLines(){
        stroke(0);  // Set line color to black
        strokeWeight(10);  // Set line thickness to 10 units
        noFill();
        // Draw all the stored lines
        for (ArrayList<float[]> line : lines) {
            if (line.size() > 1) {
                for (int i = 0; i < line.size() - 1; i++) {
                    float[] p1 = line.get(i);
                    float[] p2 = line.get(i + 1);
                    line(p1[0], p1[1], p2[0], p2[1]);  // Draw lines between consecutive points
                }
            }
        }

        // Draw the currently dragged line in real-time (if drawing)
        if (drawingLine && currentLine.size() > 1) {
            for (int i = 0; i < currentLine.size() - 1; i++) {
                float[] p1 = currentLine.get(i);
                float[] p2 = currentLine.get(i + 1);
                line(p1[0], p1[1], p2[0], p2[1]);  // Draw the line segments as they are created
            }
        }
    }

    /**
     * Checks if a given ball matches a hole based on their sprite paths and colors.
     * 
     * This method verifies if the ball and hole are valid (not null) and have not been scored before.
     * It retrieves the color information from the sprite paths of the ball and hole, seeing if they match.
     * If they match, it sets the correctCapture flag to true; otherwise, it adds the ball back to the config balls
     * for future spawning, updates the queue display if space is available, and checks if spawning should resume.
     *
     * @param ball the Ball object to check
     * @param hole the Hole object to check against
     */
    public void isMatchingBallAndHole(Ball ball, Hole hole) {
        if (ball == null || hole == null) {
            return;
        }
    
        if (!scoredBalls.contains(ball)) {
            String ballPath = ball.getSpritePath();
            String holePath = hole.getSpritePath();
    
            if (ballPath == null || holePath == null) {
                System.out.println("Ball or Hole sprite path is null. Skipping this check.");
                return;
            }
            
             // Retrieve color characters from paths
            char ballColorChar = ballPath.charAt(ballPath.length() - 5);
            char holeColorChar = holePath.charAt(holePath.length() - 5);
            
            // Check if the ball color matches the hole color
            if (ballColorChar == holeColorChar || ballColorChar == '0' || holeColorChar == '0') {
                this.correctCapture = true;
            } else {
                this.correctCapture = false;
                
                // Add the ball back to configballs
                configballs.add(ballPath);
                
                // Update the queue display if there's room
                if (queuedBallImages.size() < MAX_VISIBLE_BALLS) {
                    PImage ballImage = loadImage(ballPath);
                    ballImage.resize(32, 32);
                    queuedBallImages.add(ballImage);
                    queuedBallPaths.add(ballPath);
                    
                    // Reset spawn timing when a ball is added back
                    //lastWrongHoleTime = millis() - totalPauseTime - totalSpawnPauseTime;
                    //adjustedLastSpawnTime = lastWrongHoleTime;
                    
                    // Check if we need to resume spawning
                    checkAndUpdateSpawningState();
                }
            }
    
            scoring(ballPath);
            scoredBalls.add(ball);
        }
    }

    /**
     * Updates the score based on whether a ball was captured correctly or incorrectly.
     * 
     * If the ball was captured correctly, it increases the score based on the color of the ball
     * and the corresponding score increase modifier. If the capture was incorrect, it decreases
     * the score based on the color of the ball and the score decrease modifier.
     *
     * @param ballPath the path of the ball sprite used to find score
     */
    public void scoring(String ballPath){ 
        LevelConfig.Level currentLvl = levelConfig.getLevels().get(0);
        if(this.correctCapture){ 
            String colorName = levelConfig.pathToName(ballPath);
        
            // Get the score increase based on the color
            int scoreIncrease = levelConfig.getScoreIncreaseFromHoleCapture(colorName);
            double modifier = levelConfig.getLevels().get(currentLevelIndex).getScoreIncreaseModifier();
            this.score += scoreIncrease * modifier;
        
        } else { 
            String colorName = levelConfig.pathToName(ballPath);
            int scoreIncrease = levelConfig.getScoreDecreaseFromWrongHole(colorName);
            double modifier = levelConfig.getLevels().get(currentLevelIndex).getScoreDecreaseModifier();
            this.score -= scoreIncrease * modifier;
        }
    }
    /**
     * Checks if all balls in both the level and spawner have been captured correctly.
     * 
     * This method iterates through the lists of balls and checks if each ball
     * has been captured, if it is present in the scored balls, and if the capture
     * was correct. Additionally, it verifies if all balls from the queue have been spawned.
     *
     * @return true if all balls are captured correctly, false otherwise
     */
    private boolean areAllBallsCapturedCorrectly() {
        // Check both level balls and spawner balls
        for (Ball ball : levelballs) {
            if (!ball.isCaptured() || !scoredBalls.contains(ball) || !correctCapture) {
                return false;
            }
        }
        
        for (Ball ball : spawnerballs) {
            if (!ball.isCaptured() || !scoredBalls.contains(ball) || !correctCapture) {
                return false;
            }
        }

        // Also check if all balls from the queue have been spawned
        return currentBallIndex >= configballs.size() && queuedBallImages.isEmpty();
    }

    /**
     * Updates the bonus score during the bonus phase of the game.
     * 
     * If the level is completed and the bonus score has not yet been added,
     * this method manages the timing and scoring during the bonus phase.
     * The score increases by one unit for each 0.067 second decrement of the remaining time
     * until the time runs out, at which point the bonus phase is completed.
     */
    private void updateBonusScore() {
        if (levelCompleted && !bonusScoreAdded) {
            if (!bonusPhaseActive) {
                // Initialize bonus phase
                bonusPhaseActive = true;
                lastBonusUpdate = millis();
                return;
            }
    
            long currentTime = millis();
            if (currentTime - lastBonusUpdate >= BONUS_UPDATE_INTERVAL) {
                // Update timer and bonus score
                if (timeRemaining > 0) {
                    timeRemaining -= BONUS_TIME_DECREMENT;
                    score += 1; // Add 1 unit of score for each 0.067 second decrement
                    bonusScore += 1;
                    lastBonusUpdate = currentTime;
                } else {
                   // End the bonus phase if time runs out  
                    timeRemaining = 0;
                    bonusScoreAdded = true;
                    bonusPhaseActive = false;
                }
            }
        }
    }

    /**
     * Draws the current score on the screen in the top-right corner of the game window.
     */
    public void drawScore() {
        fill(0); // Set text color to black
        textSize(20); // Set text size
        textAlign(RIGHT, TOP); // Align text to the top-right corner
        text("Score: " + (int)score, WIDTH - 10, 40); // Display the score in the top right corner
    }

    /**
     * Updates the positions of the walls during the bonus phase.
     * 
     * The walls move in a clockwise path based on their current position.
     * The movement occurs only when the bonus phase is active and the game is not paused.
     * The position update is controlled by a time interval defined by 0.067 seconds
     */
    private void updateWallPositions() {
        if (!bonusPhaseActive || paused) return;
        
        long currentTime = millis();
        if (currentTime - lastWallMove >= WALL_MOVE_INTERVAL) {
            // Update positions based on current position state
            switch (wallPosition) {
                case 0: // Moving along top
                    if (topLeftWall.getX() < WIDTH - WALL_SIZE) {
                        topLeftWall.setX((int) topLeftWall.getX() + WALL_SIZE);
                        bottomRightWall.setX((int) bottomRightWall.getX() - WALL_SIZE);
                    } else {
                        wallPosition = 1;
                    }
                    break;
                    
                case 1: // Moving along right
                    if (topLeftWall.getY() < HEIGHT - WALL_SIZE) {
                        topLeftWall.setY((int) topLeftWall.getY() + WALL_SIZE);
                        bottomRightWall.setY((int) bottomRightWall.getY() - WALL_SIZE);
                    } else {
                        wallPosition = 2;
                    }
                    break;
                    
                case 2: // Moving along bottom
                    if (topLeftWall.getX() > 0) {
                        topLeftWall.setX((int) topLeftWall.getX() - WALL_SIZE);
                        bottomRightWall.setX((int) bottomRightWall.getX() + WALL_SIZE);
                    } else {
                        wallPosition = 3;
                    }
                    break;
                    
                case 3: // Moving along left
                    if (topLeftWall.getY() > TOPBAR) {
                        topLeftWall.setY((int) topLeftWall.getY() - WALL_SIZE);
                        bottomRightWall.setY((int) bottomRightWall.getY() + WALL_SIZE);
                    } else {
                        wallPosition = 0;
                    }
                    break;
            }
            lastWallMove = currentTime;
        }
    }
    
    /**
     * Draws the moving walls on the screen if the bonus phase is active.
     *
     * This method calls the draw method on the top left and bottom right walls
     * to render them in their current positions during the bonus phase.
     */
    private void drawMovingWalls() {
        if (bonusPhaseActive) {
            topLeftWall.draw(this);
            bottomRightWall.draw(this);
        }
    }

    /**
     * Resets the common state of the game to prepare for a new round or level.
     * 
     * This method clears all lines drawn, resets ball collections, timers, spawning 
     * states, level completion flags, bonus scoring, and wall positions. 
     */
    private void resetCommonState() {
        // Reset lines and drawing state
        this.lines.clear();
        this.currentLine = new ArrayList<>();
        this.drawingLine = false;
        
        // Reset ball collections
        this.spawnerballs.clear();
        this.scoredBalls.clear();
        
        // Reset timers
        this.lastTimeCheck = millis();
        this.adjustedLastSpawnTime = millis();
        this.totalPauseTime = 0;
        this.pauseStartTime = 0;
        
        // Reset spawning system state
        this.isSpawningActive = true;
        this.wasSpawningActive = true;
        this.timeWhenSpawningPaused = 0;
        this.totalSpawnPauseTime = 0;
        this.lastWrongHoleTime = 0;
        
        // Reset level completion states
        this.levelCompleted = false;
        this.bonusScoreAdded = false;
        this.bonusScore = 0;
        this.bonusPhaseActive = false;
        this.lastBonusUpdate = 0;
        this.transitioningToNextLevel = false;
        
        // Reset wall positions
        resetWallPositions();
    }
    
    /**
     * Resets the positions of the bonus walls to their initial state.
     * 
     * This method sets the top left wall to the top-left corner of the game 
     * area and the bottom right wall to the bottom-right corner, ensuring 
     * they are positioned correctly at the start of the game or level.
     */
    private void resetWallPositions() {
        if (topLeftWall != null) {
            topLeftWall.setX(0);
            topLeftWall.setY(TOPBAR);
        }
        if (bottomRightWall != null) {
            bottomRightWall.setX(WIDTH - WALL_SIZE);
            bottomRightWall.setY(HEIGHT - WALL_SIZE);
        }
        wallPosition = 0;
        lastWallMove = 0;
    }
    
    /**
     * Loads the game layout for a specific level and updates object references.
     * 
     * This method initializes the game layout based on the specified level number,
     * loading relevant data from a text file that describes the layout of walls, 
     * balls, holes, and spawners for that level. It also updates references 
     * to these game objects for use in the game logic.
     *
     * @param levelNumber which level to load. 
     */
    private void loadGameLayout(int levelNumber) {
        this.gameLayout = new GameLayout();
        this.gameLayout.loadLayout("level" + levelNumber + ".txt", this);
        
        // Update references to game objects
        this.walls = gameLayout.getWalls();
        this.levelballs = gameLayout.getBalls();
        this.holes = gameLayout.getHoles();
        this.spawners = gameLayout.getSpawners();
    }
    
    /**
     * Configures the settings for the specified level.
     * 
     * This method sets the spawn interval, remaining time, initial time, 
     * and ball configuration based on the provided level's settings. 
     * It also initializes the ball queue to prepare for gameplay.
     *
     * @param level the level configuration to apply
     */
    private void configureLevelSettings(LevelConfig.Level level) {
        this.SPAWN_INTERVAL = level.getSpawnInterval() * 1000;
        this.timeRemaining = level.getTime();
        this.Initial_Time = this.timeRemaining;
        this.configballs = level.getBalls();
        this.timeUp = false;
        
        // Reset ball queue
        this.currentBallIndex = 0;
        initializeBallQueue();
    }
    
    /**
     * Resets the current level to its initial state for reset.
     *
     * This method clears the common state, resets the score, and 
     * reconfigures the level settings. It also loads the layout for 
     * the current level to ensure all game elements are properly set up.
     */
    private void resetLevel() {
        resetCommonState();
        
        // Reset score for current level
        this.score = 0;
        
        // Reset level-specific configuration
        LevelConfig.Level currentLevel = levelConfig.getLevels().get(currentLevelIndex);
        configureLevelSettings(currentLevel);
        
        // Load current level layout
        loadGameLayout(currentLevelIndex + 1);
        
        this.gameCompleted = false;
    }
    
    /**
     * Resets the entire game state to its initial configuration. 
     * 
     * This method clears the common state, resets the score, 
     * and sets the current level index to zero. It configures 
     * the first level and loads its layout to prepare for gameplay.
     */
    private void resetGame() {
        resetCommonState();
        
        // Reset game-wide states
        this.score = 0;
        this.currentLevelIndex = 0;
        this.gameCompleted = false;
        
        // Configure first level
        LevelConfig.Level firstLevel = levelConfig.getLevels().get(0);
        configureLevelSettings(firstLevel);
        
        // Load first level layout
        loadGameLayout(1);
    }
    
    /**
     * Loads the next level in the game, if available.
     * 
     * This method increments the current level index and checks if the 
     * next level exists. If it does, it resets the common state, resets 
     * the score, and configures the new level settings. If all levels 
     * have been completed, it marks the game as completed.
     */
    private void loadNextLevel() {
        currentLevelIndex++;
        if (currentLevelIndex < levelConfig.getLevels().size()) {
            resetCommonState();
            
            // Reset score for new level
            this.score = 0;
            
            // Configure new level settings
            LevelConfig.Level newLevel = levelConfig.getLevels().get(currentLevelIndex);
            configureLevelSettings(newLevel);
            
            // Load new level layout
            loadGameLayout(currentLevelIndex + 1);
        } else {
            // Game completed - all levels finished
            gameCompleted = true;
        }
    }

    /**
     * Draws the current frame of the game.
     * 
     * This method is called continuously to render the game state on the screen. 
     * It handles drawing the background, layout, score, balls, timers, and 
     * other game elements. It also manages game states such as completion, 
     * pausing, and level transitions.
     */
    @Override
    public void draw() {
        background(200);
        gameLayout.drawLayout(this);
        this.drawScore();

        if (gameCompleted) {
            textAlign(CENTER, CENTER);
            fill(0);
            textSize(25);
            text("==ENDED==",  WIDTH / 2, 30);
            textSize(25);
            return;
        }

        drawSpawnBar();

        for (Ball ball : levelballs) {
            ball.draw(this); 
        }

        for (Ball ball : spawnerballs) {
            ball.draw(this);  // Draw ball
        }

        if (!levelCompleted && !timeUp) {
            levelCompleted = areAllBallsCapturedCorrectly();
        }
    
        // Update bonus score if in bonus phase
        if (levelCompleted) {
            updateBonusScore();
            if (bonusPhaseActive) {
                updateWallPositions();
                drawMovingWalls();
            }
        }

        if (levelCompleted && bonusScoreAdded && !transitioningToNextLevel) {
            transitioningToNextLevel = true;
            levelCompleteTime = millis();
        }
        
        if (transitioningToNextLevel) {
            if (millis() - levelCompleteTime >= LEVEL_TRANSITION_DELAY) {
                loadNextLevel();
            }
        }

        if (timeUp && !levelCompleted) {
            textAlign(CENTER, TOP);  
            fill(0); 
            textSize(25); 
            text("==TIME'S UP==", WIDTH / 2 + 30, TOPBAR / 2 - 15); 
            drawTimer();
            return;
        }

        if (paused) {
            // If the game is paused, display the "PAUSED" text
            fill(0);
            textSize(25);
            textAlign(CENTER, CENTER);
            text("**PAUSED**", WIDTH / 2, 30);
            this.drawLines();
            drawTimer();
            return;
        }


        drawSpawnCountdown();

        spawnBallsFromSpawners();
        
        updateTimer();  
        drawTimer();

        for (Ball ball : levelballs) {
            ball.tick(lines);
            if(ball.isCaptured() && !scoredBalls.contains(ball)) {
                this.isMatchingBallAndHole(ball, ball.capturedHole());
            }
        }

        for (Ball ball : spawnerballs) {
            ball.tick(lines);
            if(ball.isCaptured() && !scoredBalls.contains(ball)) {
                this.isMatchingBallAndHole(ball, ball.capturedHole());
            }
        }

        this.drawLines();
    }

    public static void main(String[] args) {
        PApplet.main("inkball.App");
    }
}
