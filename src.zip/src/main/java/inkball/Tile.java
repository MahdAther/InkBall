package inkball;

import processing.core.PImage;

/**
 * The {@code Tile} class represents a tile in the Inkball game. It extends the {@code GameObject} abstract
 * class and provides functionality specific to a tile, such as its position and appearance.
 */
public class Tile extends GameObject {

    /**
     * Constructor for a {@code Tile} object with the specified image, position, and sprite path.
     *
     * @param sprite     the {@code PImage} representing the visual appearance of the tile
     * @param x          the x-coordinate of the tile's position
     * @param y          the y-coordinate of the tile's position
     * @param spritePath the file path to the sprite image used for the tile
     */

    public Tile(PImage sprite, float x, float y, String spritePath) {
        //Invoked GameObject construtor to create object Tile. 
        super(sprite, x, y, spritePath);
    }
}
